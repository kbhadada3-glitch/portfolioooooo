# Keshav Bhadada — Portfolio

A static portfolio website built with HTML, CSS and JavaScript.

## Run locally

Open `index.html` in your browser. Keep the `assets/` folder beside it so the project images and videos load correctly.

## Publish with GitHub Pages

1. Create a new repository on GitHub.
2. Upload `index.html`, the `assets/` folder, `.nojekyll`, and this README to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then click **Save**.
6. Wait for GitHub Pages to publish the site; the public URL will appear in the Pages settings.

## Notes

- Keep file and folder names unchanged, including capitalization.
- This is a static site; no build command is required.
- If the site uses third-party CDN libraries, visitors need an internet connection for those libraries to load.
